from . import tetranerf_cpp_extension as cpp
triangulate = cpp.triangulate